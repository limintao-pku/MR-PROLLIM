mypaste<-function(m){
    return(apply(m,1,FUN=paste,collapse=","))
  }

