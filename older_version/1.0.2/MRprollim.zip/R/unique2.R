unique2<-function(x){
      x<-na.omit(x)
      return(unique(x))
    }

