my_moni<-function(begin,i,n){
        cat(begin,i,"/",n,"\r")
        if(i==n){cat(begin,i,"/",n,"\r\n")}
      }

