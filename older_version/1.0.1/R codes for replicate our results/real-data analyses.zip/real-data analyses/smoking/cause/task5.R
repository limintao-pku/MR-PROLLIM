library(data.table)
library(cause)
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/env_trait.Rdata")
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/cause_func.Rdata")

    set.seed(5)
    fit_cause <- mycause("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/smoke/cause/20160.gwas.imputed_v3.both_sexes.tsv", "/home/limintao/new_desktop/ukb_analysis/gwas_data/I9_HEARTFAIL.gwas.imputed_v3.both_sexes.tsv", clump_p = 0.001, p_cut2 = 1e-07)
    z <- summary(fit_cause$res, digits = 5)
    z$p
    z$tab
    summary.est_out(fit_cause, sd = 1)
    save(fit_cause, file = "/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/smoke/cause/cause_smoke_heartf.Rdata")
    
