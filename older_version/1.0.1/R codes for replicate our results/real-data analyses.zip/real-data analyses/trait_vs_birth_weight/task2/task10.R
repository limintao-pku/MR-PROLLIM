

    library(MRprollim)
    load("/gpfs/share/home/1610306125/new_desktop/ukb_analysis/env_trait.Rdata")
    load('/gpfs/share/home/1610306125/new_desktop/ukb_analysis/trait_vs_b_weight_data/data2/tea_b_weight.Rdata')
    load('/gpfs/share/home/1610306125/new_desktop/ukb_analysis/trait_vs_b_weight_data/data2/mydata_f_tea.Rdata')
    '/gpfs/share/home/1610306125/new_desktop/ukb_analysis/trait_vs_b_weight_data/data2/tea_b_weight.Rdata'
update_fit_p3_data<-function(fit_p3_data,p_cut,type){
  if(type=="b"){
    stopifnot(identical(length(fit_p3_data$wald_p),nrow(fit_p3_data$m_hat)))
    stopifnot(!anyNA(fit_p3_data$wald_p))
    loc<-which(fit_p3_data$wald_p<p_cut)
    fit_p3_data$m_hat<-fit_p3_data$m_hat[loc,]
    fit_p3_data$m_sigma<-fit_p3_data$m_sigma[loc,]
    fit_p3_data$k_hat<-fit_p3_data$k_hat[loc,]
    fit_p3_data$k_sigma<-fit_p3_data$k_sigma[loc]
    fit_p3_data$mkp_sigma_list<-fit_p3_data$mkp_sigma_list[loc]
    fit_p3_data$wald_p<-fit_p3_data$wald_p[loc]
    fit_p3_data$mkp_ind_list<-fit_p3_data$mkp_ind_list[loc]
    fit_p3_data$nonNA_loc_list<-fit_p3_data$nonNA_loc_list[loc]
    if(!is.null(fit_p3_data$u_input)){fit_p3_data$u_input<-p_cut}
  }
  fit_p3_data
}
fit_p3_data<-update_fit_p3_data(fit_p3_data,1e-4,"b")
    set.seed(11)
    if (TRUE) {
        fit_p3 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 30, est_type = "p3", snp_exp_check = F, p_snp = 1e-4, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), control_p3 = list(n_snp_limit = 10,p1_sp=1,p2_sp=0), data_p3 = fit_p3_data)
        print(tryCatch({
            MRprollim::summary.mrp(fit_p3, sd = 1)
        }, error = function(e) {
            "e"
        }))
        nrow(fit_p3$data$m_hat)
    }
    set.seed(11)
    fit_mmqr_data <- MRprollim::data_p32data_me_mo_q_re(data_p3 = fit_p3_data, length_all = length(mydata_f$x), p_cut = 1e-05)
    fit_mmqr <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 30, est_type = "me_mo_q_re", snp_exp_check = F, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), control_p3 = list(n_snp_limit = 10), data_me_mo_q_re = fit_mmqr_data)
    tryCatch({
        MRprollim::summary.mrp(fit_mmqr, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(11)
    fit_p12_data <- MRprollim::data_p32data_p12(fit_p3_data, 1e-05)
    fit_p1 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 30, est_type = "p1", snp_exp_check = F, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
    tryCatch({
        MRprollim::summary.mrp(fit_p1, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(11)
    fit_p2 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 30, est_type = "p2", snp_exp_check = F, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
    tryCatch({
        MRprollim::summary.mrp(fit_p2, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(11)
    fit_p22 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 30, est_type = "p2", snp_exp_check = F, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = T), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
    tryCatch({
        MRprollim::summary.mrp(fit_p22, sd = 1)
    }, error = function(e) {
        "e"
    })
    #save(fit_p3, fit_p3_data, file = paste0(stringr::str_remove_all('/gpfs/share/home/1610306125/new_desktop/ukb_analysis/trait_vs_b_weight_data/data2/tea_b_weight.Rdata', ".Rdata"), "_mrp_new.Rdata"))
