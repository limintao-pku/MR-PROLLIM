library(data.table)
library(cause)
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/env_trait.Rdata")
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/cause_func.Rdata")

    set.seed(8)
    fit_cause <- mycause("/home/limintao/new_desktop/ukb_analysis/gwas_data/HDL.tsv", "/home/limintao/new_desktop/ukb_analysis/gwas_data/b_weight.tsv", clump_p = 0.001, p_cut2 = 1e-07)
    "/home/limintao/new_desktop/ukb_analysis/gwas_data/HDL.tsv"
    z <- summary(fit_cause$res, digits = 5)
    z$p
    z$tab
    summary.est_out(fit_cause, sd = 1)
    save(fit_cause, file = "/home/limintao/new_desktop/ukb_analysis/exposure_vs_b_weight/cause/HDL.Rdata")
    
