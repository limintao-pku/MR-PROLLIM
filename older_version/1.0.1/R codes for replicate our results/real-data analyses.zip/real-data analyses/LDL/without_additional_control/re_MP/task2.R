
    library(MRprollim)
    load("/data/limintao_data2/MRprollim_trait/env_trait.Rdata")
    load('/data/limintao_data2/MRprollim_trait/LDL_nocv/arrhy_icd.Rdata')
    load('/data/limintao_data2/MRprollim_trait/LDL_nocv/mydata_f2.Rdata')
    '/data/limintao_data2/MRprollim_trait/LDL_nocv/arrhy_icd.Rdata'
    set.seed(3078002)
    if (TRUE) {
        fit_p3 <- MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "p3", snp_exp_check = F, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), control_p3 = list(n_snp_limit = 10), data_p3 = fit_p3$data)
        print(tryCatch({
            MRprollim::summary.mrp(fit_p3, sd = 1)
        }, error = function(e) {
            "e"
        }))
        sd(mydata_f$x)
        nrow(fit_p3$data$m_hat)
    }
    set.seed(3078002)
    fit_mmqr <- MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "me_mo_q_re", snp_exp_check = T, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F), control_p3 = list(n_snp_limit = 10))
    tryCatch({
        MRprollim::summary.mrp(fit_mmqr, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(3078002)
    fit_dhp <- tryCatch({
        MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "p1", snp_exp_check = T, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F, return_data_dhp = T), control_p3 = list(n_snp_limit = 10))
    }, error = function(e) {
        e$message
    })
    set.seed(3078002)
    fit_p1 <- tryCatch({
        MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "p1", snp_exp_check = T, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F, return_data_dhp = F), data_dhp = fit_dhp, data_nohp = fit_mmqr$data_me_mo_q_re, control_p3 = list(n_snp_limit = 10))
    }, error = function(e) {
        e$message
    })
    tryCatch({
        MRprollim::summary.mrp(fit_p1, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(3078002)
    fit_p2 <- tryCatch({
        MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "p2", snp_exp_check = T, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = F, return_data_dhp = F), data_dhp = fit_dhp, data_nohp = fit_mmqr$data_me_mo_q_re, control_p3 = list(n_snp_limit = 10))
    }, error = function(e) {
        e$message
    })
    tryCatch({
        MRprollim::summary.mrp(fit_p2, sd = 1)
    }, error = function(e) {
        "e"
    })
    set.seed(3078002)
    fit_p22 <- tryCatch({
        MRprollim::est_proc_cont(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, mc.cores = 30, est_type = "p2", snp_exp_check = T, p_snp = 1e-05, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025,0.975)), control_p12 = list(stage1_simplification = T, return_data_dhp = F), data_dhp = fit_dhp, data_nohp = fit_mmqr$data_me_mo_q_re, control_p3 = list(n_snp_limit = 10))
    }, error = function(e) {
        e$message
    })
    tryCatch({
        MRprollim::summary.mrp(fit_p22, sd = 1)
    }, error = function(e) {
        "e"
    })
    save(fit_p3, fit_mmqr, fit_p1, fit_p2, fit_p22, file = paste0(stringr::str_remove_all('/data/limintao_data2/MRprollim_trait/LDL_nocv/arrhy_icd.Rdata', ".Rdata"), "_mrp_new.Rdata"))

