library(data.table)
library(cause)
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/env_trait.Rdata")
load("/home/limintao/new_desktop/ukb_analysis/ali2_hf_data/cause_func.Rdata")

    set.seed(6)
    fit_cause <- mycause("/home/limintao/new_desktop/ukb_analysis/b_weight/cause/20022_raw.gwas.imputed_v3.both_sexes.tsv", "/home/limintao/new_desktop/ukb_analysis/gwas_data/C_STROKE.gwas.imputed_v3.both_sexes.tsv", clump_p = 0.001, p_cut2 = 1e-07)
    z <- summary(fit_cause$res, digits = 5)
    z$p
    z$tab
    summary.est_out(fit_cause, sd = 1)
    save(fit_cause, file = "/home/limintao/new_desktop/ukb_analysis/b_weight/cause/cause_b_weight_stroke.Rdata")
    
