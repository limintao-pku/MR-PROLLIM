load("/gpfs/share/home/1610306125/new_desktop/simulation/sim_env2.Rdata")
library(parallel)
library(stringr)
library(MRprollim)
crt_MR_g<-function(n_snp,n_sample,p_minor){
  #this function generates genotype data
  p_minor<-rbind(p_minor)
  out<-matrix(NA,nrow=n_sample,ncol=n_snp)
  for(i in 1:n_snp){
    x<-rbinom(n_sample,1,1-(1-p_minor[,i])^2)
    y<-rbinom(n_sample,1,p_minor[,i]^2/(1-(1-p_minor[,i])^2))+1L
    x[x==1]<-y[x==1]
    out[,i]<-x
  }
  return(out)
}

my_task<-function(n_rep){
  n=80000
  n_snp=20
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  mc.cores<-1
  dt<-F
  parallel_trace<-F
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  t0<-Sys.time()
  my_proc<-0
  myseed<-list()
  f<-function(k1,k2,p1){
    dis<-suppressWarnings(abs(log(k2/k1/2)))
    dis[is.na(dis)]<-Inf
    loc<-which(abs(k1)>=median(abs(k1)))
    out<-rep(p1,length(k1))
    out[loc]<-as.numeric(dis[loc]<quantile(dis[loc],p1))
    out
  }
  for(i in 1:n_rep){
    myseed[[i]]<-.Random.seed
    for(m in 1:1){
      while(T){
        c<-rbinom(n,1,0.5)
        u1<-sqrt(1-0.2^2)*rnorm(n,0,1)+0.2*c*2
        u2<-sqrt(0.5)*u1+sqrt(0.5)*rnorm(n,0,1)
        
        pg<-runif(n_snp,0.15,0.35);k_c<-runif(n_snp,-0.1,0.1)
        g<-crt_MR_g(n_snp,n,matrix(pg,nrow=n,ncol=n_snp,byrow=T)+matrix(c-0.5,nrow=n,ncol=n_snp)*matrix(k_c,nrow=n,ncol=n_snp,byrow=T))
        g3<-g2<-g
        colnames(g)<-paste0("rs",1:n_snp)
        
        if(T){
          sk_2<-0.38^2;sk_22<-0.04^2
          out11<-rbind(mvrnorm(n_snp/2,c(0,0),matrix(c(sk_2*1,sk_2*2*0.7,sk_2*2*0.7,sk_2*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*0.7,sk_22*2*0.7,sk_22*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*1,sk_22*2*1,sk_22*4),2)))
          k1<-out11[,1]
          k2<-out11[,2]
        }
        #plot(k1,k2);abline(a=0,b=2);abline(v=0);abline(h=0);cor(k1,k2)
        
        b1<-0.3
        p1<-0.3
        p2<-0.5#
        u1_p<-1#
        s1_2<-0.06^2#
        u2_m<-0#
        p3<-1
        
        out22<-matrix(NA,ncol=2,nrow=n_snp)
        
        p1<-rep(p1,n_snp)
        #p1<-rep(p1,n_snp)
        
        for(j in 1:n_snp){
          q<-rbinom(1,1,p1[j])
          q1<-rbinom(1,1,p2)
          q2<-rbinom(1,1,p3)
          rho<-switch(q2+1,1,0.7)
          
          out22[j,]<-q*(mvrnorm(1,c(0,0),matrix(c(s1_2*1,s1_2*2*rho,s1_2*2*rho,s1_2*4),2))+
                          c( k1[j]*u1_p , 2*k1[j]*u1_p )*q1+c(u2_m,2*u2_m)
          )+(1-q)*c(0,0)
          
          g2[which(g[,j]==1),j]<-k1[j]
          g2[which(g[,j]==2),j]<-k2[j]
          
          g3[which(g[,j]==1),j]<-out22[j,1]
          g3[which(g[,j]==2),j]<-out22[j,2]
        }
        
        if(F){
          z<-g2%*%rep(1,n_snp)
          summary2(z)
          z[z>=2.5]<-2.5
          
          fit<-nlm(f=f_log_linear,p=c(0,-1),x=x,g=z,c=NULL)
          a<-f_log_linear(fit$estimate,x=x,g=z,c=NULL,grad=F)
          b<-f_log_linear(log(mean(x)),x=x,g=NULL,c=NULL,grad=F)
          (1-exp(2/n*(-b+a)))/(1-exp(2/n*(-b)))
        }
        
        if(T){
          px<-0.5*u1+g2%*%rep(1,n_snp)+0.2*c
          px<-exp(px-mean(px)-2.5)
          j1<-mean(px>1)#;print(j1)
          #print(quantile(px,c(0.50,0.99,0.999,0.9999,1)))
          px[px>=1]<-1
          x<-rbinom(n,1,px)
          #print(mean(x))
        }
        
        if(T){
          py<-0.5*u2+b1*x+g3%*%rep(1,n_snp)+0.2*c
          py<-exp(py-mean(py)-2.3)
          j2<-mean(py>1)#;print(j2)
          #print(quantile(py,c(0.50,0.99,0.999,0.9999,1)))
          py[py>=1]<-1
          y<-rbinom(n,1,py)
          #print(mean(y))
        }
        if(j1<0.01&j2<0.01){break}
      }
      fit0<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                             est_type="p3",snp_exp_check=T,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(1))),
                                             control_p3=list(n_snp_limit=7,inspect_data_p3=T))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p3=list(n_snp_limit=7),data_p3=fit0,
                                               control_global_search=list(global_search=T,
                                                                          genoud_control=list(pop.size=10)))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,1)$sum_data,
                                       model=summary.mrp(fit_p3,1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=n,p_cut=1e-6)},error=function(e){"error"})
      
      fit_me<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,1))},error=function(e){list(NULL)})
      
      fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,p_cut=1e-6)},error=function(e){"e"})

      fit_p1<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,1))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,1))},error=function(e){list(NULL)})

      fit_p22<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,1))},error=function(e){list(NULL)})
    }
    my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,myseed))
}
#b1<-0.3
#p1<-0.3
#p2<-0.5#
#u1_p<-1#
#s1_2<-0.06^2#
#u2_m<-0#
#p3<-1
set.seed(2023032211)
out<-mclapply(even_allo2(600,30),FUN=my_task,mc.cores=30)
save(out,file="/gpfs/share/home/1610306125/new_desktop/simulation/20SNP_bi_rerun/sim_out11.Rdata")

my_task<-function(n_rep){
  n=80000
  n_snp=20
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  mc.cores<-1
  dt<-F
  parallel_trace<-F
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  t0<-Sys.time()
  my_proc<-0
  myseed<-list()
  f<-function(k1,k2,p1){
    dis<-suppressWarnings(abs(log(k2/k1/2)))
    dis[is.na(dis)]<-Inf
    loc<-which(abs(k1)>=median(abs(k1)))
    out<-rep(p1,length(k1))
    out[loc]<-as.numeric(dis[loc]<quantile(dis[loc],p1))
    out
  }
  for(i in 1:n_rep){
    myseed[[i]]<-.Random.seed
    for(m in 1:1){
      while(T){
        c<-rbinom(n,1,0.5)
        u1<-sqrt(1-0.2^2)*rnorm(n,0,1)+0.2*c*2
        u2<-sqrt(0.5)*u1+sqrt(0.5)*rnorm(n,0,1)
        
        pg<-runif(n_snp,0.15,0.35);k_c<-runif(n_snp,-0.1,0.1)
        g<-crt_MR_g(n_snp,n,matrix(pg,nrow=n,ncol=n_snp,byrow=T)+matrix(c-0.5,nrow=n,ncol=n_snp)*matrix(k_c,nrow=n,ncol=n_snp,byrow=T))
        g3<-g2<-g
        colnames(g)<-paste0("rs",1:n_snp)
        
        if(T){
          sk_2<-0.38^2;sk_22<-0.04^2
          out11<-rbind(mvrnorm(n_snp/2,c(0,0),matrix(c(sk_2*1,sk_2*2*0.7,sk_2*2*0.7,sk_2*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*0.7,sk_22*2*0.7,sk_22*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*1,sk_22*2*1,sk_22*4),2)))
          k1<-out11[,1]
          k2<-out11[,2]
        }
        #plot(k1,k2);abline(a=0,b=2);abline(v=0);abline(h=0);cor(k1,k2)
        
        b1<-0.3
        p1<-0.5
        p2<-0.5#
        u1_p<-1#
        s1_2<-0.06^2#
        u2_m<-0#
        p3<-1
        
        out22<-matrix(NA,ncol=2,nrow=n_snp)
        
        p1<-rep(p1,n_snp)
        #p1<-rep(p1,n_snp)
        
        for(j in 1:n_snp){
          q<-rbinom(1,1,p1[j])
          q1<-rbinom(1,1,p2)
          q2<-rbinom(1,1,p3)
          rho<-switch(q2+1,1,0.7)
          
          out22[j,]<-q*(mvrnorm(1,c(0,0),matrix(c(s1_2*1,s1_2*2*rho,s1_2*2*rho,s1_2*4),2))+
                          c( k1[j]*u1_p , 2*k1[j]*u1_p )*q1+c(u2_m,2*u2_m)
          )+(1-q)*c(0,0)
          
          g2[which(g[,j]==1),j]<-k1[j]
          g2[which(g[,j]==2),j]<-k2[j]
          
          g3[which(g[,j]==1),j]<-out22[j,1]
          g3[which(g[,j]==2),j]<-out22[j,2]
        }
        
        if(F){
          z<-g2%*%rep(1,n_snp)
          summary2(z)
          z[z>=2.5]<-2.5
          
          fit<-nlm(f=f_log_linear,p=c(0,-1),x=x,g=z,c=NULL)
          a<-f_log_linear(fit$estimate,x=x,g=z,c=NULL,grad=F)
          b<-f_log_linear(log(mean(x)),x=x,g=NULL,c=NULL,grad=F)
          (1-exp(2/n*(-b+a)))/(1-exp(2/n*(-b)))
        }
        
        if(T){
          px<-0.5*u1+g2%*%rep(1,n_snp)+0.2*c
          px<-exp(px-mean(px)-2.5)
          j1<-mean(px>1)#;print(j1)
          #print(quantile(px,c(0.50,0.99,0.999,0.9999,1)))
          px[px>=1]<-1
          x<-rbinom(n,1,px)
          #print(mean(x))
        }
        
        if(T){
          py<-0.5*u2+b1*x+g3%*%rep(1,n_snp)+0.2*c
          py<-exp(py-mean(py)-2.3)
          j2<-mean(py>1)#;print(j2)
          #print(quantile(py,c(0.50,0.99,0.999,0.9999,1)))
          py[py>=1]<-1
          y<-rbinom(n,1,py)
          #print(mean(y))
        }
        if(j1<0.01&j2<0.01){break}
      }
      fit0<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                             est_type="p3",snp_exp_check=T,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(1))),
                                             control_p3=list(n_snp_limit=7,inspect_data_p3=T))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p3=list(n_snp_limit=7),data_p3=fit0,
                                               control_global_search=list(global_search=T,
                                                                          genoud_control=list(pop.size=10)))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,1)$sum_data,
                                       model=summary.mrp(fit_p3,1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=n,p_cut=1e-6)},error=function(e){"error"})
      
      fit_me<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,1))},error=function(e){list(NULL)})
      
      fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,p_cut=1e-6)},error=function(e){"e"})

      fit_p1<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,1))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,1))},error=function(e){list(NULL)})

      fit_p22<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,1))},error=function(e){list(NULL)})
    }
    my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,myseed))
}
#b1<-0.3
#p1<-0.5
#p2<-0.5#
#u1_p<-1#
#s1_2<-0.06^2#
#u2_m<-0#
#p3<-1
set.seed(2023032212)
out<-mclapply(even_allo2(600,30),FUN=my_task,mc.cores=30)
save(out,file="/gpfs/share/home/1610306125/new_desktop/simulation/20SNP_bi_rerun/sim_out12.Rdata")

my_task<-function(n_rep){
  n=80000
  n_snp=20
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  mc.cores<-1
  dt<-F
  parallel_trace<-F
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  t0<-Sys.time()
  my_proc<-0
  myseed<-list()
  f<-function(k1,k2,p1){
    dis<-suppressWarnings(abs(log(k2/k1/2)))
    dis[is.na(dis)]<-Inf
    loc<-which(abs(k1)>=median(abs(k1)))
    out<-rep(p1,length(k1))
    out[loc]<-as.numeric(dis[loc]<quantile(dis[loc],p1))
    out
  }
  for(i in 1:n_rep){
    myseed[[i]]<-.Random.seed
    for(m in 1:1){
      while(T){
        c<-rbinom(n,1,0.5)
        u1<-sqrt(1-0.2^2)*rnorm(n,0,1)+0.2*c*2
        u2<-sqrt(0.5)*u1+sqrt(0.5)*rnorm(n,0,1)
        
        pg<-runif(n_snp,0.15,0.35);k_c<-runif(n_snp,-0.1,0.1)
        g<-crt_MR_g(n_snp,n,matrix(pg,nrow=n,ncol=n_snp,byrow=T)+matrix(c-0.5,nrow=n,ncol=n_snp)*matrix(k_c,nrow=n,ncol=n_snp,byrow=T))
        g3<-g2<-g
        colnames(g)<-paste0("rs",1:n_snp)
        
        if(T){
          sk_2<-0.38^2;sk_22<-0.04^2
          out11<-rbind(mvrnorm(n_snp/2,c(0,0),matrix(c(sk_2*1,sk_2*2*0.7,sk_2*2*0.7,sk_2*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*0.7,sk_22*2*0.7,sk_22*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*1,sk_22*2*1,sk_22*4),2)))
          k1<-out11[,1]
          k2<-out11[,2]
        }
        #plot(k1,k2);abline(a=0,b=2);abline(v=0);abline(h=0);cor(k1,k2)
        
        b1<-0.3
        p1<-0.7
        p2<-0.5#
        u1_p<-1#
        s1_2<-0.06^2#
        u2_m<-0#
        p3<-1
        
        out22<-matrix(NA,ncol=2,nrow=n_snp)
        
        p1<-rep(p1,n_snp)
        #p1<-rep(p1,n_snp)
        
        for(j in 1:n_snp){
          q<-rbinom(1,1,p1[j])
          q1<-rbinom(1,1,p2)
          q2<-rbinom(1,1,p3)
          rho<-switch(q2+1,1,0.7)
          
          out22[j,]<-q*(mvrnorm(1,c(0,0),matrix(c(s1_2*1,s1_2*2*rho,s1_2*2*rho,s1_2*4),2))+
                          c( k1[j]*u1_p , 2*k1[j]*u1_p )*q1+c(u2_m,2*u2_m)
          )+(1-q)*c(0,0)
          
          g2[which(g[,j]==1),j]<-k1[j]
          g2[which(g[,j]==2),j]<-k2[j]
          
          g3[which(g[,j]==1),j]<-out22[j,1]
          g3[which(g[,j]==2),j]<-out22[j,2]
        }
        
        if(F){
          z<-g2%*%rep(1,n_snp)
          summary2(z)
          z[z>=2.5]<-2.5
          
          fit<-nlm(f=f_log_linear,p=c(0,-1),x=x,g=z,c=NULL)
          a<-f_log_linear(fit$estimate,x=x,g=z,c=NULL,grad=F)
          b<-f_log_linear(log(mean(x)),x=x,g=NULL,c=NULL,grad=F)
          (1-exp(2/n*(-b+a)))/(1-exp(2/n*(-b)))
        }
        
        if(T){
          px<-0.5*u1+g2%*%rep(1,n_snp)+0.2*c
          px<-exp(px-mean(px)-2.5)
          j1<-mean(px>1)#;print(j1)
          #print(quantile(px,c(0.50,0.99,0.999,0.9999,1)))
          px[px>=1]<-1
          x<-rbinom(n,1,px)
          #print(mean(x))
        }
        
        if(T){
          py<-0.5*u2+b1*x+g3%*%rep(1,n_snp)+0.2*c
          py<-exp(py-mean(py)-2.3)
          j2<-mean(py>1)#;print(j2)
          #print(quantile(py,c(0.50,0.99,0.999,0.9999,1)))
          py[py>=1]<-1
          y<-rbinom(n,1,py)
          #print(mean(y))
        }
        if(j1<0.01&j2<0.01){break}
      }
      fit0<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                             est_type="p3",snp_exp_check=T,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(1))),
                                             control_p3=list(n_snp_limit=7,inspect_data_p3=T))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p3=list(n_snp_limit=7),data_p3=fit0,
                                               control_global_search=list(global_search=T,
                                                                          genoud_control=list(pop.size=10)))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,1)$sum_data,
                                       model=summary.mrp(fit_p3,1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=n,p_cut=1e-6)},error=function(e){"error"})
      
      fit_me<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,1))},error=function(e){list(NULL)})
      
      fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,p_cut=1e-6)},error=function(e){"e"})

      fit_p1<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,1))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,1))},error=function(e){list(NULL)})

      fit_p22<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,1))},error=function(e){list(NULL)})
    }
    my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,myseed))
}
#b1<-0.3
#p1<-0.7
#p2<-0.5#
#u1_p<-1#
#s1_2<-0.06^2#
#u2_m<-0#
#p3<-1
set.seed(2023032213)
out<-mclapply(even_allo2(600,30),FUN=my_task,mc.cores=30)
save(out,file="/gpfs/share/home/1610306125/new_desktop/simulation/20SNP_bi_rerun/sim_out13.Rdata")

my_task<-function(n_rep){
  n=80000
  n_snp=20
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  mc.cores<-1
  dt<-F
  parallel_trace<-F
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  t0<-Sys.time()
  my_proc<-0
  myseed<-list()
  f<-function(k1,k2,p1){
    dis<-suppressWarnings(abs(log(k2/k1/2)))
    dis[is.na(dis)]<-Inf
    loc<-which(abs(k1)>=median(abs(k1)))
    out<-rep(p1,length(k1))
    out[loc]<-as.numeric(dis[loc]<quantile(dis[loc],p1))
    out
  }
  for(i in 1:n_rep){
    myseed[[i]]<-.Random.seed
    for(m in 1:1){
      while(T){
        c<-rbinom(n,1,0.5)
        u1<-sqrt(1-0.2^2)*rnorm(n,0,1)+0.2*c*2
        u2<-sqrt(0.5)*u1+sqrt(0.5)*rnorm(n,0,1)
        
        pg<-runif(n_snp,0.15,0.35);k_c<-runif(n_snp,-0.1,0.1)
        g<-crt_MR_g(n_snp,n,matrix(pg,nrow=n,ncol=n_snp,byrow=T)+matrix(c-0.5,nrow=n,ncol=n_snp)*matrix(k_c,nrow=n,ncol=n_snp,byrow=T))
        g3<-g2<-g
        colnames(g)<-paste0("rs",1:n_snp)
        
        if(T){
          sk_2<-0.38^2;sk_22<-0.04^2
          out11<-rbind(mvrnorm(n_snp/2,c(0,0),matrix(c(sk_2*1,sk_2*2*0.7,sk_2*2*0.7,sk_2*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*0.7,sk_22*2*0.7,sk_22*4),2)),mvrnorm(n_snp/4,c(0,0),matrix(c(sk_22*1,sk_22*2*1,sk_22*2*1,sk_22*4),2)))
          k1<-out11[,1]
          k2<-out11[,2]
        }
        #plot(k1,k2);abline(a=0,b=2);abline(v=0);abline(h=0);cor(k1,k2)
        
        b1<-0
        p1<-0.3
        p2<-0.5#
        u1_p<-1#
        s1_2<-0.06^2#
        u2_m<-0#
        p3<-1
        
        out22<-matrix(NA,ncol=2,nrow=n_snp)
        
        p1<-rep(p1,n_snp)
        #p1<-rep(p1,n_snp)
        
        for(j in 1:n_snp){
          q<-rbinom(1,1,p1[j])
          q1<-rbinom(1,1,p2)
          q2<-rbinom(1,1,p3)
          rho<-switch(q2+1,1,0.7)
          
          out22[j,]<-q*(mvrnorm(1,c(0,0),matrix(c(s1_2*1,s1_2*2*rho,s1_2*2*rho,s1_2*4),2))+
                          c( k1[j]*u1_p , 2*k1[j]*u1_p )*q1+c(u2_m,2*u2_m)
          )+(1-q)*c(0,0)
          
          g2[which(g[,j]==1),j]<-k1[j]
          g2[which(g[,j]==2),j]<-k2[j]
          
          g3[which(g[,j]==1),j]<-out22[j,1]
          g3[which(g[,j]==2),j]<-out22[j,2]
        }
        
        if(F){
          z<-g2%*%rep(1,n_snp)
          summary2(z)
          z[z>=2.5]<-2.5
          
          fit<-nlm(f=f_log_linear,p=c(0,-1),x=x,g=z,c=NULL)
          a<-f_log_linear(fit$estimate,x=x,g=z,c=NULL,grad=F)
          b<-f_log_linear(log(mean(x)),x=x,g=NULL,c=NULL,grad=F)
          (1-exp(2/n*(-b+a)))/(1-exp(2/n*(-b)))
        }
        
        if(T){
          px<-0.5*u1+g2%*%rep(1,n_snp)+0.2*c
          px<-exp(px-mean(px)-2.5)
          j1<-mean(px>1)#;print(j1)
          #print(quantile(px,c(0.50,0.99,0.999,0.9999,1)))
          px[px>=1]<-1
          x<-rbinom(n,1,px)
          #print(mean(x))
        }
        
        if(T){
          py<-0.5*u2+b1*x+g3%*%rep(1,n_snp)+0.2*c
          py<-exp(py-mean(py)-2.3)
          j2<-mean(py>1)#;print(j2)
          #print(quantile(py,c(0.50,0.99,0.999,0.9999,1)))
          py[py>=1]<-1
          y<-rbinom(n,1,py)
          #print(mean(y))
        }
        if(j1<0.01&j2<0.01){break}
      }
      fit0<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                             est_type="p3",snp_exp_check=T,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(1))),
                                             control_p3=list(n_snp_limit=7,inspect_data_p3=T))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p3=list(n_snp_limit=7),data_p3=fit0,
                                               control_global_search=list(global_search=T,
                                                                          genoud_control=list(pop.size=10)))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,1)$sum_data,
                                       model=summary.mrp(fit_p3,1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=n,p_cut=1e-6)},error=function(e){"error"})
      
      fit_me<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,1))},error=function(e){list(NULL)})
      
      fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,p_cut=1e-6)},error=function(e){"e"})

      fit_p1<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,1))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,1))},error=function(e){list(NULL)})

      fit_p22<-tryCatch({MRprollim::est_proc_bi(x,y,g,list(cbind(c)),dum_loc_list=list(c(1)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=parallel_trace,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(1))),
                                               control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,1))},error=function(e){list(NULL)})
    }
    my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,myseed))
}
#b1<-0
#p1<-0.3
#p2<-0.5#
#u1_p<-1#
#s1_2<-0.06^2#
#u2_m<-0#
#p3<-1
set.seed(2023032214)
out<-mclapply(even_allo2(600,30),FUN=my_task,mc.cores=30)
save(out,file="/gpfs/share/home/1610306125/new_desktop/simulation/20SNP_bi_rerun/sim_out14.Rdata")