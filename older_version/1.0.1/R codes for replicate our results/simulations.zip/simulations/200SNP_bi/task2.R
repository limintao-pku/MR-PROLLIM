load("/home/limintao/new_desktop/ukb_analysis/simulation/sim_env.Rdata")
library(parallel)
library(stringr)
library(CompQuadForm)
library(MASS)
library(Matrix);library(MRprollim)
my_task<-function(n_rep){
  t0<-Sys.time()
  my_proc<-0
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  snp_name<-list()
  seed<-list()
  mc.cores<-1
  dt<-F
  for(i in 1:n_rep){
    seed[[i]]<-.Random.seed
    if(T){
      get_effect_snp_out<-get_effect_snp2(s2=0.008702375,n=200,rho=0.9)
      get_c_out<-get_c2(50000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.3,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0.78-0.3745,
                            test_y2=F,
                            dt=dt)
      #dim(mydata$g_matr)
      fit1<-get_sig_snp(mydata$x,mydata$g_matr,list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      
      loc<-which(fit1$p<1e-3)
      
      fit2<-get_ind2(colnames(mydata$g_matr)[loc],fit1$p[loc],pid=pid,dt=F)
      #length(fit2)
      
      get_c_out<-get_c2(50000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.3,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0.78-0.3745,
                            test_y2=F,
                            dt=dt)
      
      loc<-which(colnames(mydata$g_matr)%in%fit2)
      
      fit3<-get_sig_snp(mydata$x,myselect(mydata$g_matr,loc),list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      loc1<-which(fit3$p<1e-5)
      #length(loc1)
      
      snp_name[[i]]<-colnames(mydata$g_matr)[loc[loc1]]

      myx<-mydata$x
      myy<-mydata$y
      myg<-myselect(mydata$g_matr,loc[loc1])
      rm(mydata);gc()
      
      fit0<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                             est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(2,3))),
                                             control_p3=list(n_snp_limit=10,inspect_data_p3=T),
                                             control_global_search=list(global_search=F))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_p3=list(n_snp_limit=10),data_p3=fit0,
                                               control_global_search=list(global_search=F))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,sd=1)$sum_data,
                                       model=summary.mrp(fit_p3,sd=1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      if(T){
        fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=50000,p_cut=1e-6)},error=function(e){"error"})
        fit_me<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
        out_me[i]<-tryCatch({list(summary.mrp(fit_me,sd=1))},error=function(e){list(NULL)})

        fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,1e-6)},error=function(e){"e"})
        fit_p1<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,sd=1))},error=function(e){list(NULL)})
        
        fit_p2<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,sd=1))},error=function(e){list(NULL)})
        
        fit_p22<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                  mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                  est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                  control_limit_c=list(dum_loc=list(c(2,3))),
                                                  control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,sd=1))},error=function(e){list(NULL)})
      }
    }
    if(T){
      my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
    }
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,snp_name,seed))
}
out_info<-"
get_effect_snp_out<-get_effect_snp2(s2=0.008702375,n=200,rho=0.9)
get_c_out<-get_c2(50000)
mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type='b',return_mr_data=T,relate=T,
                      b1=0,test_x=F,r2u=0.09,
                      par_h=list(p1=0.3,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                      res_r2=0.78-0.3745,
                      test_y2=F,
                      dt=dt)
set.seed(2022122704)                      
"
set.seed(2022122704)
out<-mclapply(even_allo2(300,30),FUN=my_task,mc.cores=30)
save(out,out_info,file="/home/limintao/new_desktop/ukb_analysis/simulation/MRprollim_200SNP_bi/sim_out4.Rdata")

my_task<-function(n_rep){
  t0<-Sys.time()
  my_proc<-0
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-list()
  snp_name<-list()
  seed<-list()
  mc.cores<-1
  dt<-F
  for(i in 1:n_rep){
    seed[[i]]<-.Random.seed
    if(T){
      get_effect_snp_out<-get_effect_snp2(s2=0.008702375,n=200,rho=0.9)
      get_c_out<-get_c2(50000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0.78-0.5315,
                            test_y2=F,
                            dt=dt)
      #dim(mydata$g_matr)
      fit1<-get_sig_snp(mydata$x,mydata$g_matr,list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      
      loc<-which(fit1$p<1e-3)
      
      fit2<-get_ind2(colnames(mydata$g_matr)[loc],fit1$p[loc],pid=pid,dt=F)
      #length(fit2)
      
      get_c_out<-get_c2(50000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0.78-0.5315,
                            test_y2=F,
                            dt=dt)
      
      loc<-which(colnames(mydata$g_matr)%in%fit2)
      
      fit3<-get_sig_snp(mydata$x,myselect(mydata$g_matr,loc),list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      loc1<-which(fit3$p<1e-5)
      #length(loc1)
      
      snp_name[[i]]<-colnames(mydata$g_matr)[loc[loc1]]

      myx<-mydata$x
      myy<-mydata$y
      myg<-myselect(mydata$g_matr,loc[loc1])
      rm(mydata);gc()
      
      fit0<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                             est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(2,3))),
                                             control_p3=list(n_snp_limit=10,inspect_data_p3=T),
                                             control_global_search=list(global_search=F))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_p3=list(n_snp_limit=10),data_p3=fit0,
                                               control_global_search=list(global_search=F))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,sd=1)$sum_data,
                                       model=summary.mrp(fit_p3,sd=1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      if(T){
        fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=50000,p_cut=1e-6)},error=function(e){"error"})
        fit_me<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
        out_me[i]<-tryCatch({list(summary.mrp(fit_me,sd=1))},error=function(e){list(NULL)})

        fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,1e-6)},error=function(e){"e"})
        fit_p1<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,sd=1))},error=function(e){list(NULL)})
        
        fit_p2<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                 mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                 est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,sd=1))},error=function(e){list(NULL)})
        
        fit_p22<-tryCatch({MRprollim::est_proc_bi(myx,myy,myg,list(get_c_out$c),c_inherit=T,dum_loc_list=list(c(2,3)),
                                                  mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                  est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                  control_limit_c=list(dum_loc=list(c(2,3))),
                                                  control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
        out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,sd=1))},error=function(e){list(NULL)})
      }
    }
    if(T){
      my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
    }
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,snp_name,seed))
}
out_info<-"
get_effect_snp_out<-get_effect_snp2(s2=0.008702375,n=200,rho=0.9)
get_c_out<-get_c2(50000)
mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type='b',return_mr_data=T,relate=T,
                      b1=0,test_x=F,r2u=0.09,
                      par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                      res_r2=0.78-0.5315,
                      test_y2=F,
                      dt=dt)
set.seed(2022122705)                      
"
set.seed(2022122705)
out<-mclapply(even_allo2(300,30),FUN=my_task,mc.cores=30)
save(out,out_info,file="/home/limintao/new_desktop/ukb_analysis/simulation/MRprollim_200SNP_bi/sim_out5.Rdata")