load("/gpfs/share/home/1610306125/new_desktop/simulation/sim_env_1000bi.Rdata")
library(parallel)
library(stringr)
library(CompQuadForm)
library(MASS)
library(Matrix)
library(MRprollim)

get_ind2<-function(name,p,pid,dt=T){
  #loc<-which(p<p_cut)
  #name<-colnames(g_matr)[loc]
  names(p)<-NULL
  info<-matrix(as.numeric(unlist(strsplit(name,split="_"))),ncol=3,byrow=T)
  info<-cbind(info,p)
  
  if(dt){cat("start ld clumping.\r\n")}
  g_u<-unique(info[,2])
  out_name<-NULL
  for(i in 1:length(g_u)){
    loc<-which(info[,2]==g_u[i])
    while(T){
      clump<-tryCatch({
        myld_clump(
          dat=data.frame(rsid=colnames(genotype_10000r)[info[loc,1]],pval=info[loc,4]),
          plink_bin="/gpfs/share/home/1610306125/new_desktop/plink/plink",
          bfile="/gpfs/share/home/1610306125/new_desktop/plink/ld_ref/mypop",
          clump_r2=0.05,clump_kb=10000,clump_p=1,pid=paste0(pid,"_",i)
        )},error=function(e){"e"})
      if(!identical(clump,"e")){break}
      Sys.sleep(as.numeric(pid))
    }
    id<-which(colnames(genotype_10000r)%in%clump$rsid)
    out_name<-c(out_name,apply(rbind(rbind(info[loc,1:3])[which(info[loc,1]%in%id),]),1,paste,collapse="_"))
    if(dt)(my_moni("group",i,length(g_u)))
  }
  return(out_name)
}

my_task<-function(n_rep){
  t0<-Sys.time()
  my_proc<-0
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-seed<-list()
  snp_name<-list()
  mc.cores<-1
  dt<-F
  for(i in 1:n_rep){
    seed[[i]]<-.Random.seed
    if(T){
      get_effect_snp_out<-get_effect_snp2(s2=0.0006304397,n=1000,rho=0.9)
      get_c_out<-get_c2(80000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="c",return_mr_data=T,relate=T,
                            b1=0.2,test_x=F,r2u=0.68,
                            par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.0006304397),
                            res_r2=0.78-0.4842,
                            test_y2=F,
                            dt=dt)
      #dim(mydata$g_matr)
      
      fit1<-get_sig_snp(mydata$x,mydata$g_matr,list(get_c_out$c),c_inherit=T,c_cat=F,type="c",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      
      loc<-which(fit1$p<1e-3)
      fit2<-get_ind2(colnames(mydata$g_matr)[loc],fit1$p[loc],pid=pid,dt=F)
      #length(fit2)
      
      get_c_out<-get_c2(80000)
      mydata<-get_ref_gwas2(get_c_out,get_effect_snp_out,type="c",return_mr_data=T,relate=T,
                            b1=0.2,test_x=F,r2u=0.68,
                            par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.0006304397),
                            res_r2=0.78-0.4842,
                            test_y2=F,
                            dt=dt)
      gc()
      loc<-which(colnames(mydata$g_matr)%in%fit2)
      
      fit3<-get_sig_snp(mydata$x,myselect(mydata$g_matr,loc),list(get_c_out$c),c_inherit=T,c_cat=F,type="c",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F)
      loc1<-which(fit3$p<1e-5)
      #length(loc1)
      
      snp_name[[i]]<-colnames(mydata$g_matr)[loc[loc1]]
      
      myx<-mydata$x
      myy<-mydata$y
      myg<-myselect(mydata$g_matr,loc[loc1])
      rm(mydata);gc()
      
      fit_p3<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                 mc.cores=mc.cores,parallel_trace=F,
                                                 est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p3=list(n_snp_limit=10),
                                                 control_global_search=list(global_search=F))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,sd(myx))$sum_data,
                                       model=summary.mrp(fit_p3,sd(myx))$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit_me<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                 mc.cores=mc.cores,parallel_trace=F,
                                                 est_type="me_mo_q_re",snp_exp_check=T,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_me_mo_q_re=NULL)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,sd(myx)))},error=function(e){list(NULL)})
      
      fit_p0<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                 mc.cores=mc.cores,parallel_trace=F,
                                                 est_type="p1",snp_exp_check=T,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(return_data_dhp=T))},error=function(e){"error"})
      
      fit_p1<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                 mc.cores=mc.cores,parallel_trace=F,
                                                 est_type="p1",snp_exp_check=T,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=NULL,data_dhp=fit_p0,data_nohp=fit_me$data_me_mo_q_re)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,sd(myx)))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                 mc.cores=mc.cores,parallel_trace=F,
                                                 est_type="p2",snp_exp_check=T,p_snp=1e-6,cd=F,
                                                 control_limit_c=list(dum_loc=list(c(2,3))),
                                                 control_p12=list(stage1_simplification=F),data_dhp=fit_p0,data_nohp=fit_me$data_me_mo_q_re)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,sd(myx)))},error=function(e){list(NULL)})
      
      fit_p22<-tryCatch({MRprollim::est_proc_cont(myx,myy,myg,list(get_c_out$c),c_inherit=T,dt=dt,
                                                  mc.cores=mc.cores,parallel_trace=F,
                                                  est_type="p2",snp_exp_check=T,p_snp=1e-6,cd=F,
                                                  control_limit_c=list(dum_loc=list(c(2,3))),
                                                  control_p12=list(stage1_simplification=T),data_dhp=fit_p0,data_nohp=fit_me$data_me_mo_q_re)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,sd(myx)))},error=function(e){list(NULL)})
      
      rm(fit_p3,fit_p0,fit_p1,fit_p2,fit_p22,fit_me);gc()
    }
    if(T){
      my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
    }
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,snp_name,seed))
}
out_info<-"#s2=0.0006304397,n=1000
#par_h=list(p1=0.5,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.0006304397)
#b1=0.2,r2u=0.68
#res_r2=0.78-0.4842
#loc<-which(fit1$p<1e-3)
#loc1<-which(fit3$p<1e-5)
#nome=F,p_snp=1e-5
set.seed(23010102)"
set.seed(230101021)
out<-mclapply(even_allo2(150,30),FUN=my_task,mc.cores=30)
save(out,out_info,file="/gpfs/share/home/1610306125/new_desktop/simulation/1000_cont/c_samplesize/sim_out2_1.Rdata")
gc()
set.seed(230101022)
out<-mclapply(even_allo2(150,30),FUN=my_task,mc.cores=30)
save(out,out_info,file="/gpfs/share/home/1610306125/new_desktop/simulation/1000_cont/c_samplesize/sim_out2_2.Rdata")