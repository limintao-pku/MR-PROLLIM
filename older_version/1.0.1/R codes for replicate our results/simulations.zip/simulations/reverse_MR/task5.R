load("/nfs-share/home/2111210111/new_desktop/simulation/sim_env.Rdata")
library(parallel)
library(MASS)
library(stringr)
library(Matrix)
library(MRprollim);load("/nfs-share/home/2111210111/new_desktop/simulation/ld_10000r_sparse_0.9.Rdata");ld_10000r_sparse_0.5<-ld_10000r_sparse_0.9

get_ind2<-function(name,p,pid,dt=T){
  names(p)<-NULL
  info<-matrix(as.numeric(unlist(strsplit(name,split="_"))),ncol=3,byrow=T)
  info<-cbind(info,p)
  
  if(dt){cat("start ld clumping.\r\n")}
  g_u<-unique(info[,2])
  out_name<-NULL
  for(i in 1:length(g_u)){
    loc<-which(info[,2]==g_u[i])
    clump<-myld_clump(
      dat=data.frame(rsid=colnames(genotype_10000r)[info[loc,1]],pval=info[loc,4]),
      plink_bin="/nfs-share/home/2111210111/new_desktop/plink/plink",
      bfile="/nfs-share/home/2111210111/new_desktop/plink/ld_ref/mypop",
      clump_r2=0.05,clump_kb=10000,clump_p=1,pid=paste0(pid,"_",i)
    )
    id<-which(colnames(genotype_10000r)%in%clump$rsid)
    out_name<-c(out_name,apply(rbind(rbind(info[loc,1:3])[which(info[loc,1]%in%id),]),1,paste,collapse="_"))
    if(dt)(my_moni("group",i,length(g_u)))
  }
  return(out_name)
}

my_task<-function(n_rep){
  t0<-Sys.time()
  my_proc<-0
  pid<-n_rep[[2]]
  n_rep<-n_rep[[1]]
  out_p3<-out_me<-out_p1<-out_p2<-out_p22<-seed<-list()
  snp_name<-list()
  mc.cores<-1;dt<-F
  for(i in 1:n_rep){
    seed[[i]]<-.Random.seed
    if(T){
      get_effect_snp_out<-get_effect_snp3(nx=200,ny=60,s2=0.008702375,rho=0.9)
      get_c_out<-get_c2(100000)
      mydata<-get_ref_gwas3(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.7,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0,
                            test_y2=F,
                            dt=dt)
      #dim(mydata$g_matr)
      #View(est_k_prior)
      gc()
      fit1<-get_sig_snp(mydata$y,mydata$g_matr,list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F,stepmax=2)
      
      loc<-which(fit1$p<1e-3)
      fit2<-get_ind2(colnames(mydata$g_matr)[loc],fit1$p[loc],pid=pid,dt=dt)
      #length(fit2)
      #table2(str_detect(fit2,"2$"))
      
      get_c_out<-get_c2(100000)
      mydata<-get_ref_gwas3(get_c_out,get_effect_snp_out,type="b",return_mr_data=T,relate=T,
                            b1=0,test_x=F,r2u=0.09,
                            par_h=list(p1=0.7,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2),
                            res_r2=0,
                            test_y2=F,
                            dt=dt)
      
      loc<-which(colnames(mydata$g_matr)%in%fit2)
      
      fit3<-get_sig_snp(mydata$y,myselect(mydata$g_matr,loc),list(get_c_out$c),c_inherit=T,c_cat=F,type="b",
                        control_limit_c=list(limit_c=T,dum_loc=list(c(2,3)),quantile=c(0.025,0.975),outlier=F),
                        mc.cores=mc.cores,nlm=T,parallel_trace=F,dt=dt,cd=F,cd_g_code=F,stepmax=2)
      loc1<-which(fit3$p<1e-5);length(loc1)
      
      snp_name[[i]]<-colnames(mydata$g_matr)[loc[loc1]]
      
      y<-mydata$y
      x<-mydata$x
      g<-myselect(mydata$g_matr,loc[loc1])
      rm(mydata);gc()
      
      fit0<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                             mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                             est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                             control_limit_c=list(dum_loc=list(c(2,3))),
                                             control_p3=list(n_snp_limit=10,inspect_data_p3=T),
                                             control_global_search=list(global_search=T,genoud_control=list(pop.size=10)))},error=function(e){"error"})
      if(identical(fit0,"error")){next}
      
      fit_p3<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="p3",snp_exp_check=F,p_snp=1e-5,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_p3=list(n_snp_limit=10),data_p3=fit0,
                                               control_global_search=list(global_search=T,genoud_control=list(pop.size=10)))},error=function(e){"error"})
      out_p3[[i]]<-tryCatch({list(list(result=summary.mrp(fit_p3,sd=1)$sum_data,
                                       model=summary.mrp(fit_p3,sd=1)$model,n_snp=nrow(fit_p3$data$m_hat),snp=rownames(fit_p3$data$m_hat),Egger=fit_p3$parameter$Egger_info))},error=function(e){list(NULL)})
      
      fit01<-tryCatch({MRprollim::data_p32data_me_mo_q_re(data_p3=fit0,length_all=100000,p_cut=1e-6)},error=function(e){"error"})
      fit_me<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="me_mo_q_re",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_me_mo_q_re=NULL,data_me_mo_q_re=fit01)},error=function(e){"error"})
      out_me[i]<-tryCatch({list(summary.mrp(fit_me,sd=1))},error=function(e){list(NULL)})
      
      fit_p12_data<-tryCatch({MRprollim::data_p32data_p12(fit0,1e-6)},error=function(e){"e"})
      fit_p1<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="p1",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p1[i]<-tryCatch({list(summary.mrp(fit_p1,sd=1))},error=function(e){list(NULL)})
      
      fit_p2<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                               mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                               est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                               control_limit_c=list(dum_loc=list(c(2,3))),
                                               control_p12=list(stage1_simplification=F),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p2[i]<-tryCatch({list(summary.mrp(fit_p2,sd=1))},error=function(e){list(NULL)})
      
      fit_p22<-tryCatch({MRprollim::est_proc_bi(y,x,g,list(get_c_out$c),dum_loc_list=list(c(2,3)),
                                                mc.cores=mc.cores,dt=dt,parallel_trace=F,
                                                est_type="p2",snp_exp_check=F,p_snp=1e-6,cd=F,
                                                control_limit_c=list(dum_loc=list(c(2,3))),
                                                control_p12=list(stage1_simplification=T),data_p12=fit_p12_data)},error=function(e){"error"})
      out_p22[i]<-tryCatch({list(summary.mrp(fit_p22,sd=1))},error=function(e){list(NULL)})
    }
    if(T){
      my_proc<-my_moni2(paste0("Child process ",pid,":"),i,n_rep,my_proc,time=T,t0=t0)
    }
  }
  return(list(out_p3,out_me,out_p1,out_p2,out_p22,snp_name,seed))
}
out_info<-"#s2=0.008702375,n=200+60
#par_h=list(p1=0.7,p2=0.5,u1=1,u2=0,rho_h=0.9,sh_2=0.08^2)
#b1=0,r2u=0.09
#res_r2=0
#loc<-which(fit1$p<1e-3)
#loc1<-which(fit3$p<1e-5)
#nome=F,p_snp=1e-5
set.seed(2022123005)"
set.seed(2022123005)
out<-mclapply(even_allo2(300,30),FUN=my_task,mc.cores=30)
save(out,out_info,file="/nfs-share/home/2111210111/new_desktop/simulation/rev/sim_out5.Rdata")