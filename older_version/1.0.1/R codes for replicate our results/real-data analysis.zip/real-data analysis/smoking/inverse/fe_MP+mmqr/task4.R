


library(MRprollim)
load("/gpfs/share/home/1610306125/new_desktop/ukb_analysis/env_trait.Rdata")
load('/gpfs/share/home/1610306125/new_desktop/ukb_analysis/smoke_p_rerun/hearta_icd.Rdata')
load('/gpfs/share/home/1610306125/new_desktop/ukb_analysis/smoke_p_rerun/mydata_f4.Rdata')
'/gpfs/share/home/1610306125/new_desktop/ukb_analysis/smoke_p_rerun/hearta_icd.Rdata'
myp1<-5e-6
myp2<-2e-6
myoutpath<-'/gpfs/share/home/1610306125/new_desktop/ukb_analysis/smoke_p_rerun/hearta_icd_new.Rdata'

set.seed(4)
fit_mmqr_data <- MRprollim::data_p32data_me_mo_q_re(data_p3 = fit_p3_data, length_all = length(mydata_f$x), p_cut = myp2)
fit_mmqr <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 20, est_type = "me_mo_q_re", snp_exp_check = F, p_snp = myp2, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025, 0.975)), control_p12 = list(k1_td_adj_m="fdr", stage1_simplification = F), control_p3 = list(n_snp_limit = 10), data_me_mo_q_re = fit_mmqr_data)
tryCatch({
    MRprollim::summary.mrp(fit_mmqr, sd = 1)
}, error = function(e) {
    "e"
})
set.seed(4)
fit_p12_data <- MRprollim::data_p32data_p12(fit_p3_data, myp2)
fit_p1 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 20, est_type = "p1", snp_exp_check = F, p_snp = myp2, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025, 0.975)), control_p12 = list(k1_td_adj_m="fdr", stage1_simplification = F), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
tryCatch({
    MRprollim::summary.mrp(fit_p1, sd = 1)
}, error = function(e) {
    "e"
})
set.seed(4)
fit_p2 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 20, est_type = "p2", snp_exp_check = F, p_snp = myp2, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025, 0.975)), control_p12 = list(k1_td_adj_m="fdr", stage1_simplification = F), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
tryCatch({
    MRprollim::summary.mrp(fit_p2, sd = 1)
}, error = function(e) {
    "e"
})
set.seed(4)
fit_p22 <- MRprollim::est_proc_bi(x = mydata_f$x, y = mydata_f$y, g = mydata_f$g, c = list(ukb_control_v[mydata_f$loc1,][mydata_f$loc2,]), c_inherit = T, dum_loc_list = list(c(11)), mc.cores = 20, est_type = "p2", snp_exp_check = F, p_snp = myp2, cd = F, control_limit_c = list(limit_c = T, dum_loc = list(c(11)), quantile = c(0.025, 0.975)), control_p12 = list(k1_td_adj_m="fdr", stage1_simplification = T), data_p12 = fit_p12_data, control_p3 = list(n_snp_limit = 10))
tryCatch({
    MRprollim::summary.mrp(fit_p22, sd = 1)
}, error = function(e) {
    "e"
})
#save(fit_p3, file = myoutpath)


