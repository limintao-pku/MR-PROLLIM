library(data.table)
library(cause)
library(ieugwasr)
load("/data/limintao_data2/home_is_full/BMI/re_run/env_trait.Rdata")
load("/data/limintao_data2/home_is_full/cause_func.Rdata")

    set.seed(3)
    fit_cause <- mycause("/home/limintao/myR/R-4.1.3/bin/env_backup/ukb_analyse/GWAS_data/angina/I20.gwas.imputed_v3.both_sexes.tsv", "/home/limintao/myR/R-4.1.3/bin/env_backup/ukb_analyse/GWAS_data/b_weight/20022_raw.gwas.imputed_v3.both_sexes.tsv", clump_p = 0.001, p_cut2 = 1e-07)
    z <- summary(fit_cause$res, digits = 5)
    z$p
    z$tab
    summary.est_out(fit_cause, sd = 1)
    save(fit_cause, file = "/data/limintao_data2/home_is_full/outcome_vs_b_weight/cause/angina.Rdata")
    
